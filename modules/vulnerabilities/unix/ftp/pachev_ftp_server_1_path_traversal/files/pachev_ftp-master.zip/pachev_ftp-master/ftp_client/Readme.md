# Caveats

Passwords are no longer hidden after 3/10/17 solely for test purposes. They can easily be added back. In order to redirect a test file like `ftp_client < test.tx` passwords needed to become plain text.
